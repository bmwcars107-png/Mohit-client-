package mohit.client;

import mohit.client.modules.*;
import net.minecraft.client.Minecraft;
import java.util.List;

public class ModuleManager {
    private static final List<Module> MODULES = List.of(
            new Sprint(), new Fullbright(), new PlayerGlow(), new AutoWalk());

    public static List<Module> all() { return MODULES; }

    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        for (Module m : MODULES) if (m.enabled) m.onTick(mc);
    }
}
