package mohit.client.modules;

import mohit.client.Module;
import net.minecraft.client.Minecraft;

public class AutoWalk extends Module {
    public AutoWalk() { super("AutoWalk", "Holds the forward key for you."); }
    @Override public void onTick(Minecraft mc) { mc.options.keyUp.setDown(true); }
    @Override public void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options != null) mc.options.keyUp.setDown(false);
    }
}
