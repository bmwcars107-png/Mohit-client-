package mohit.client.modules;

import mohit.client.Module;
import net.minecraft.client.Minecraft;

public class Sprint extends Module {
    public Sprint() { super("Sprint", "Sprints automatically while moving forward."); }
    @Override public void onTick(Minecraft mc) {
        if (mc.options.keyUp.isDown()) mc.options.keySprint.setDown(true);
    }
    @Override public void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options != null) mc.options.keySprint.setDown(false);
    }
}
