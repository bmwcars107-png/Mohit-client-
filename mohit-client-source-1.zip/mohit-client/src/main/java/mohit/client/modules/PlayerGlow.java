package mohit.client.modules;

import mohit.client.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/** Simple player highlight using the vanilla glow outline (client-side only). */
public class PlayerGlow extends Module {
    public PlayerGlow() { super("PlayerGlow", "Outlines other players so they are easy to see."); }
    @Override public void onTick(Minecraft mc) {
        for (Entity e : mc.level.entitiesForRendering())
            if (e instanceof Player p && p != mc.player) p.setGlowingTag(true);
    }
    @Override public void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        for (Entity e : mc.level.entitiesForRendering())
            if (e instanceof Player p && p != mc.player) p.setGlowingTag(false);
    }
}
