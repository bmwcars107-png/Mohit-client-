package mohit.client;

import mohit.client.gui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class MohitClient implements ClientModInitializer {
    private static KeyMapping openGui;

    @Override
    public void onInitializeClient() {
        Config.load();

        openGui = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.mohitclient.gui", GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyMapping.Category.register(Identifier.fromNamespaceAndPath("mohitclient", "main"))));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.consumeClick()) mc.setScreen(new ClickGuiScreen());
            ModuleManager.tick(mc);
        });

        // HUD: watermark + list of enabled modules in the theme colour
        HudRenderCallback.EVENT.register((g, tick) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options.hideGui) return;
            g.drawString(mc.font, "Mohit Client", 4, 4, Config.color, true);
            List<Module> on = new ArrayList<>();
            for (Module m : ModuleManager.all()) if (m.enabled) on.add(m);
            on.sort(Comparator.comparingInt((Module m) -> -mc.font.width(m.name)));
            int w = mc.getWindow().getGuiScaledWidth(), y = 4;
            for (Module m : on) {
                g.drawString(mc.font, m.name, w - mc.font.width(m.name) - 4, y, Config.color, true);
                y += 10;
            }
        });
    }
}
