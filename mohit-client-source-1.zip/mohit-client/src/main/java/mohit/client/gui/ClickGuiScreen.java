package mohit.client.gui;

import mohit.client.Config;
import mohit.client.Module;
import mohit.client.ModuleManager;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class ClickGuiScreen extends Screen {
    private static final int W = 170, ROW = 18, BG = 0xE0141418, ROW_BG = 0xE01E1E26, OFF = 0xFF8A8A96;
    private static final int[] PRESETS = {0xFF7C3AED, 0xFF3B82F6, 0xFF10B981, 0xFFEF4444, 0xFFF59E0B, 0xFFEC4899, 0xFFFFFFFF};
    private int x, y, dragging = -1; // dragging: 0=R 1=G 2=B

    public ClickGuiScreen() { super(Component.literal("Mohit Client")); }

    @Override protected void init() { x = width / 2 - W / 2; y = height / 2 - 100; }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void onClose() { Config.save(); super.onClose(); }

    private int sliderY(int i) { return y + 20 + ModuleManager.all().size() * ROW + 34 + i * 14; }
    private int presetY() { return y + 20 + ModuleManager.all().size() * ROW + 16; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        int accent = Config.color;
        int h = 20 + ModuleManager.all().size() * ROW + 96;
        g.fill(x, y, x + W, y + h, BG);
        g.fill(x, y, x + W, y + 18, accent);
        g.drawString(font, "Mohit Client", x + 6, y + 5, 0xFFFFFFFF, true);

        int ry = y + 20;
        for (Module m : ModuleManager.all()) {
            boolean hover = mx >= x && mx < x + W && my >= ry && my < ry + ROW;
            g.fill(x + 2, ry, x + W - 2, ry + ROW - 1, hover ? 0xE02A2A34 : ROW_BG);
            if (m.enabled) g.fill(x + 2, ry, x + 4, ry + ROW - 1, accent);
            g.drawString(font, m.name, x + 9, ry + 5, m.enabled ? accent : OFF, false);
            ry += ROW;
        }

        g.drawString(font, "Colour", x + 6, ry + 4, 0xFFFFFFFF, false);
        int px = x + 6;
        for (int c : PRESETS) { g.fill(px, presetY(), px + 16, presetY() + 12, c); px += 22; }

        String[] n = {"R", "G", "B"};
        int[] v = {(accent >> 16) & 255, (accent >> 8) & 255, accent & 255};
        for (int i = 0; i < 3; i++) {
            int sy = sliderY(i);
            g.drawString(font, n[i], x + 6, sy + 1, OFF, false);
            g.fill(x + 20, sy + 3, x + W - 8, sy + 6, 0xFF33333D);
            int hx = x + 20 + (int) ((W - 28) * (v[i] / 255.0));
            g.fill(hx - 2, sy, hx + 2, sy + 9, accent);
        }
        super.render(g, mx, my, delta);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        int ry = y + 20;
        for (Module m : ModuleManager.all()) {
            if (mx >= x && mx < x + W && my >= ry && my < ry + ROW) { m.toggle(); return true; }
            ry += ROW;
        }
        int px = x + 6;
        for (int c : PRESETS) {
            if (mx >= px && mx < px + 16 && my >= presetY() && my < presetY() + 12) { Config.color = c; return true; }
            px += 22;
        }
        for (int i = 0; i < 3; i++)
            if (my >= sliderY(i) && my < sliderY(i) + 10 && mx >= x + 20 && mx <= x + W - 8) { dragging = i; setChannel(mx); return true; }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (dragging >= 0) { setChannel(e.x()); return true; }
        return super.mouseDragged(e, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        if (dragging >= 0) { dragging = -1; Config.save(); return true; }
        return super.mouseReleased(e);
    }

    private void setChannel(double mx) {
        int val = (int) Math.max(0, Math.min(255, (mx - (x + 20)) / (W - 28) * 255));
        int c = Config.color;
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        if (dragging == 0) r = val; else if (dragging == 1) g = val; else b = val;
        Config.color = 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
