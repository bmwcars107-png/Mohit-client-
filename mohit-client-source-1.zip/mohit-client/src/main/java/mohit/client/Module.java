package mohit.client;

import net.minecraft.client.Minecraft;

public abstract class Module {
    public final String name, description;
    public boolean enabled;

    protected Module(String name, String description) { this.name = name; this.description = description; }

    public void toggle() { setEnabled(!enabled); Config.save(); }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        if (on) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(Minecraft mc) {}
}
