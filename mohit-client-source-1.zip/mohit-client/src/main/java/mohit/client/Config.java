package mohit.client;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

/** Saves theme colour and which modules are on to .minecraft/config/mohit-client.json */
public class Config {
    public static int color = 0xFF7C3AED; // ARGB accent colour
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("mohit-client.json");

    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            JsonObject o = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            if (o.has("color")) color = o.get("color").getAsInt();
            if (o.has("modules")) {
                JsonObject m = o.getAsJsonObject("modules");
                for (Module mod : ModuleManager.all())
                    if (m.has(mod.name) && m.get(mod.name).getAsBoolean()) mod.setEnabled(true);
            }
        } catch (Exception e) { System.err.println("[Mohit] config load failed: " + e); }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("color", color);
            JsonObject m = new JsonObject();
            for (Module mod : ModuleManager.all()) m.addProperty(mod.name, mod.enabled);
            o.add("modules", m);
            Files.writeString(FILE, new GsonBuilder().setPrettyPrinting().create().toJson(o));
        } catch (Exception e) { System.err.println("[Mohit] config save failed: " + e); }
    }
}
