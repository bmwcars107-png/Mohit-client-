# Mohit Client (Fabric, Minecraft 1.21.11)

Original code. Modules: Sprint, Fullbright, PlayerGlow, AutoWalk. HUD module list, click GUI
(RIGHT SHIFT) with colour presets + RGB sliders; settings saved to config/mohit-client.json.

## Build
Requires JDK 21 and Gradle (or add the Gradle wrapper with `gradle wrapper`).

    gradle build

Jar appears in build/libs/mohit-client-1.0.0.jar  -> put in .minecraft/mods with Fabric API.

If a version in gradle.properties is rejected, copy current values from https://fabricmc.net/develop
(Minecraft 1.21.11). 1.21.9+ changed input/keybind/HUD APIs; if the compiler flags a method,
send the error and it's a one-line fix.
