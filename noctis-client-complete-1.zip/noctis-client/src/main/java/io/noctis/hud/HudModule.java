package io.noctis.hud;

import io.noctis.module.Category;
import io.noctis.module.Module;
import io.noctis.module.Status;
import io.noctis.setting.BoolSetting;
import io.noctis.setting.ColorSetting;
import io.noctis.setting.NumSetting;
import net.minecraft.client.gui.DrawContext;

/** A draggable HUD element. Position, scale, opacity, colour and background are independent per element. */
public abstract class HudModule extends Module {
    public final NumSetting x, y, scale, opacity;
    public final BoolSetting background;
    public final ColorSetting color;

    protected HudModule(String name, String description, int defX, int defY, int accentRgb) {
        super(name, description, Category.HUD, Status.IMPLEMENTED);
        x = add(new NumSetting("X", "Horizontal position", defX, 0, 8192, 1));
        y = add(new NumSetting("Y", "Vertical position", defY, 0, 8192, 1));
        x.hide(); y.hide();
        scale = add(new NumSetting("Scale", "Element size multiplier", 1.0, 0.5, 2.5, 0.05));
        opacity = add(new NumSetting("Opacity", "Overall opacity", 1.0, 0.1, 1.0, 0.05));
        background = add(new BoolSetting("Background", "Draw a panel behind the element", true));
        color = add(new ColorSetting("Accent", "Accent colour for this element", accentRgb));
    }

    /** Unscaled content size. */
    public abstract int w();
    public abstract int h();
    /** Draw at local origin (0,0); alpha already includes the opacity setting. */
    public abstract void draw(DrawContext c, float alpha);

    public int sw() { return Math.round(w() * scale.floatVal()); }
    public int sh() { return Math.round(h() * scale.floatVal()); }
}
