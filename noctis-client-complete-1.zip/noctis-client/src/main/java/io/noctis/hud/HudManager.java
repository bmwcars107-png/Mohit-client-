package io.noctis.hud;

import io.noctis.gui.HudEditorScreen;
import io.noctis.module.Module;
import io.noctis.module.ModuleManager;
import io.noctis.gui.Render2D;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class HudManager {
    /** True while the HUD editor is open so elements can show sample data. */
    public static boolean preview;

    private HudManager() {}

    public static void render(DrawContext c) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || mc.currentScreen instanceof HudEditorScreen) return;
        for (Module m : ModuleManager.all()) {
            if (m instanceof HudModule h && h.isEnabled()) renderOne(c, h);
        }
    }

    public static void renderOne(DrawContext c, HudModule h) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int maxX = Math.max(0, mc.getWindow().getScaledWidth() - h.sw());
        int maxY = Math.max(0, mc.getWindow().getScaledHeight() - h.sh());
        int px = Math.min(h.x.intVal(), maxX), py = Math.min(h.y.intVal(), maxY);
        Render2D.push(c, px, py, h.scale.floatVal());
        try {
            h.draw(c, h.opacity.floatVal());
        } catch (Throwable t) {
            h.setEnabled(false);          // a broken element must never break the HUD or the game
            h.lastError = t.getClass().getSimpleName();
        } finally {
            Render2D.pop(c);
        }
    }
}
