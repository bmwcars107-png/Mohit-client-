package io.noctis.hooks;

import io.noctis.module.impl.ExtraModules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

/** Called by HeldItemRendererMixin. Keeps all logic out of the mixin class. */
public final class ViewModelHook {
    private ViewModelHook() {}

    /** Number of times the mixin has fired; ViewModel uses it to tell whether the hook is actually installed. */
    public static volatile long calls;

    public static void apply(MatrixStack m, Hand hand) {
        calls++;
        ExtraModules.ViewModel vm = ExtraModules.VIEW_MODEL;
        if (vm == null || !vm.isEnabled() || !vm.appliesTo(hand)) return;
        var p = MinecraftClient.getInstance().player;
        // +X always means "away from the body", whichever hand and whichever main arm the player uses.
        float side = (hand == Hand.MAIN_HAND) == (p == null || p.getMainArm() == Arm.RIGHT) ? 1f : -1f;
        m.translate(vm.x() * side, vm.y(), vm.z());
        if (vm.rotX() != 0) m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(vm.rotX()));
        if (vm.rotY() != 0) m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(vm.rotY() * side));
        if (vm.rotZ() != 0) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(vm.rotZ() * side));
        float s = vm.scale();
        if (s != 1f) m.scale(s, s, s);
    }
}
