package io.noctis.hooks;

import io.noctis.module.impl.ExtraModules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Called by EntityRendererMixin after vanilla filled the render state. Only edits text vanilla already decided to show. */
public final class NametagHook {
    private NametagHook() {}

    public static volatile long calls;

    public static void apply(Entity entity, EntityRenderState state) {
        calls++;
        ExtraModules.Nametags nm = ExtraModules.NAMETAGS;
        if (nm == null || !nm.isEnabled() || state == null || state.displayName == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || entity == mc.player || !(entity instanceof LivingEntity le)) return;
        boolean isPlayer = entity instanceof PlayerEntity;
        if (!isPlayer && !nm.mobs()) return;

        MutableText t = state.displayName.copy();
        if (nm.health()) {
            float hp = le.getHealth(), max = Math.max(1f, le.getMaxHealth());
            float frac = hp / max;
            Formatting c = frac > 0.66f ? Formatting.GREEN : frac > 0.33f ? Formatting.YELLOW : Formatting.RED;
            String s = String.format(java.util.Locale.ROOT, " %.1f", hp);
            float abs = le.getAbsorptionAmount();
            if (abs > 0) s += String.format(java.util.Locale.ROOT, "+%.1f", abs);
            t.append(Text.literal(s + "\u2764").formatted(c));
        }
        if (nm.distance()) t.append(Text.literal(" " + (int) mc.player.distanceTo(entity) + "m").formatted(Formatting.GRAY));
        if (nm.ping() && isPlayer && mc.getNetworkHandler() != null) {
            var entry = mc.getNetworkHandler().getPlayerListEntry(entity.getUuid());
            if (entry != null) t.append(Text.literal(" " + entry.getLatency() + "ms").formatted(Formatting.DARK_GRAY));
        }
        state.displayName = t;
    }
}
