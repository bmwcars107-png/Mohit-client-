package io.noctis.hooks;

import io.noctis.module.impl.ExtraModules;
import net.minecraft.util.math.Vec2f;

/** Called by KeyboardInputMixin right after the keyboard filled Input.movementVector. */
public final class MoveFixHook {
    private MoveFixHook() {}

    public static volatile long calls;

    /**
     * Movement is computed as R(yaw) * (sideways, forward). If a module turned the view by delta degrees since
     * the previous input tick, feeding R(-delta) * input keeps the world-space direction of travel unchanged.
     */
    public static Vec2f rotate(Vec2f in) {
        calls++;
        ExtraModules.MoveFix mf = ExtraModules.MOVE_FIX;
        if (mf == null || !mf.isEnabled()) return in;
        float d = mf.consume();
        if (d == 0f || (in.x == 0f && in.y == 0f)) return in;
        double r = Math.toRadians(d), c = Math.cos(r), s = Math.sin(r);
        return new Vec2f((float) (in.x * c + in.y * s), (float) (in.y * c - in.x * s));
    }
}
