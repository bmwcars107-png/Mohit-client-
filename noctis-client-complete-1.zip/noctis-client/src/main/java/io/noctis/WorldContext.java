package io.noctis;

import net.minecraft.client.MinecraftClient;

/**
 * Classifies the world the client is in, using the integrated server itself instead of guessing from
 * the presence of other players.
 * <ul>
 *   <li>{@link Kind#SOLO}: integrated server, you are the only player online (also true if the world is
 *       opened to LAN but nobody has joined).</li>
 *   <li>{@link Kind#LAN_HOST}: integrated server (you are the host) and at least one other player is online.</li>
 *   <li>{@link Kind#REMOTE}: you are connected to someone else's server (dedicated, realm, or a friend's LAN
 *       world joined as a guest). Nothing here is ever relaxed.</li>
 * </ul>
 * Limitation: from the host's client there is no verified API to tell "open to LAN" from "not open" when
 * nobody has joined, so that case is (harmlessly) treated as SOLO.
 */
public final class WorldContext {
    public enum Kind { NONE, SOLO, LAN_HOST, REMOTE }

    private WorldContext() {}

    public static Kind current() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return Kind.NONE;
        if (!mc.isInSingleplayer()) return Kind.REMOTE;
        var srv = mc.getServer();
        if (srv == null) return Kind.SOLO;
        return srv.getCurrentPlayerCount() > 1 ? Kind.LAN_HOST : Kind.SOLO;
    }

    public static String describe(Kind k) {
        return switch (k) {
            case NONE -> "no world";
            case SOLO -> "your own singleplayer world";
            case LAN_HOST -> "your own world with guests (LAN)";
            case REMOTE -> "a remote server";
        };
    }
}
