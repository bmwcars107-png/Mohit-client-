package io.noctis.mixin;

import io.noctis.hooks.CapeHook;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Capes hook: swaps the cape texture on the render state of the LOCAL player only (verified Yarn 1.21.11 signature). */
@Mixin(CapeFeatureRenderer.class)
public abstract class CapeFeatureRendererMixin {
    @Inject(method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/PlayerEntityRenderState;FF)V",
            at = @At("HEAD"))
    private void noctis$cape(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
                             PlayerEntityRenderState state, float limbAngle, float limbDistance, CallbackInfo ci) {
        CapeHook.apply(state);
    }
}
