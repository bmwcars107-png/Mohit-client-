package io.noctis.mixin;

import io.noctis.hooks.ViewModelHook;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ViewModel hook. Target verified against Yarn 1.21.11 (HeldItemRenderer.renderFirstPersonItem with an
 * OrderedRenderCommandQueue parameter). Lives in noctis-extra.mixins.json (required=false): if the target is
 * ever missing, only this mixin is skipped and ViewModel reports "hook inactive".
 */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;push()V", shift = At.Shift.AFTER, ordinal = 0))
    private void noctis$viewModel(AbstractClientPlayerEntity player, float tickProgress, float pitch, Hand hand,
                                  float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                                  OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        ViewModelHook.apply(matrices, hand);
    }
}
