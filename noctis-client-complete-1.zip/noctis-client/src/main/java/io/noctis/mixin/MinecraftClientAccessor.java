package io.noctis.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {
    @Accessor("itemUseCooldown")
    int noctis$getItemUseCooldown();

    @Accessor("itemUseCooldown")
    void noctis$setItemUseCooldown(int value);
}
