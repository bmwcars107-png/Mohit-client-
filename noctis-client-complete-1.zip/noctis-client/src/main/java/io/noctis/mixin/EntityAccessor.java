package io.noctis.mixin;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Lives in the optional noctis-extra.mixins.json: if the field name is wrong for this version, only NoWeb is lost. */
@Mixin(Entity.class)
public interface EntityAccessor {
    @Accessor("movementMultiplier")
    void noctis$setMovementMultiplier(Vec3d value);
}
