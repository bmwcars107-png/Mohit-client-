package io.noctis.module.impl;

import io.noctis.NoctisClient;
import io.noctis.config.ConfigManager;
import io.noctis.gui.ClickGuiScreen;
import io.noctis.module.*;
import io.noctis.module.Module;
import io.noctis.setting.*;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Locale;
import java.util.Set;

import static io.noctis.module.impl.Modules.unavailable;

public final class MiscModules {
    private MiscModules() {}

    public static ClientThemes THEMES;
    public static TeamsModule TEAMS;
    private static CommandLogger LOGGER;

    static void register() {
        ModuleManager.register(new ClickGui());
        ModuleManager.register(THEMES = new ClientThemes());
        ModuleManager.register(LOGGER = new CommandLogger());
        ModuleManager.register(new Export());
        ModuleManager.register(TEAMS = new TeamsModule());
        ModuleManager.register(new SelfDestruct());
        ModuleManager.register(new Transactions());
    }

    // ------------------------------------------------------------------------------------------
    public static final class ClickGui extends ActionModule {
        public static ClickGui INSTANCE;
        public final NumSetting animSpeed = add(new NumSetting("Animation speed", "Open/close animation speed", 1.0, 0.5, 2.5, 0.1));
        public final BoolSetting descriptions = add(new BoolSetting("Descriptions", "Show module descriptions in the list", true));
        public ClickGui() {
            super("ClickGUI", "Opens the Noctis interface. Default key: Right Shift.", Category.MISC, Status.IMPLEMENTED);
            defaultKey = 344; // GLFW_KEY_RIGHT_SHIFT
            INSTANCE = this;
        }
        @Override protected void run() { mc.setScreen(new ClickGuiScreen()); }
    }

    // ------------------------------------------------------------------------------------------
    public static final class ClientThemes extends Module {
        private final ModeSetting preset = add(new ModeSetting("Preset", "Accent colour pair", "Amethyst", "Amethyst", "Crimson", "Silver", "Custom"));
        private final ColorSetting customA = add(new ColorSetting("Primary", "Custom primary accent", 0x8B5CF6));
        private final ColorSetting customB = add(new ColorSetting("Secondary", "Custom secondary accent", 0xE11D48));
        private final NumSetting opacity = add(new NumSetting("Window opacity", "ClickGUI window opacity", 0.96, 0.6, 1.0, 0.01));
        public ClientThemes() {
            super("ClientThemes", "Accent colours and window opacity for the ClickGUI and HUD.", Category.MISC, Status.IMPLEMENTED);
            defaultEnabled = true;
            customA.showIf(() -> preset.is("Custom"));
            customB.showIf(() -> preset.is("Custom"));
        }
        public int primary() {
            if (!isEnabled()) return 0xFF8B5CF6;
            return switch (preset.get()) { case "Crimson" -> 0xFFE11D48; case "Silver" -> 0xFFC4C9D4; case "Custom" -> customA.rgb(); default -> 0xFF8B5CF6; };
        }
        public int secondary() {
            if (!isEnabled()) return 0xFFE11D48;
            return switch (preset.get()) { case "Crimson" -> 0xFF8B5CF6; case "Silver" -> 0xFF8B5CF6; case "Custom" -> customB.rgb(); default -> 0xFFE11D48; };
        }
        public float windowOpacity() { return isEnabled() ? opacity.floatVal() : 0.96f; }
    }

    // ------------------------------------------------------------------------------------------
    private static final Set<String> SENSITIVE = Set.of("login", "l", "log", "register", "reg", "password", "changepassword", "cp", "passwd", "2fa", "auth");

    /** True for authentication-style commands (login, register, ...). Never logged and never sent by macros. */
    public static boolean isSensitive(String command) {
        String first = command.trim().split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        if (first.startsWith("/")) first = first.substring(1);
        return SENSITIVE.contains(first);
    }

    public static void logCommand(String command) {
        if (LOGGER == null || !LOGGER.isEnabled()) return;
        LOGGER.write(command);
    }

    public static final class CommandLogger extends Module {
        private final BoolSetting stamp = add(new BoolSetting("Timestamps", "Prefix each line with the time", true));
        public CommandLogger() { super("CommandLogger", "Writes the commands YOU type to config/noctis/command-log.txt (local file only). Authentication-style commands are never recorded.", Category.MISC, Status.IMPLEMENTED); }
        void write(String command) {
            String first = command.trim().split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
            if (SENSITIVE.contains(first)) return;
            try {
                Path f = FabricLoader.getInstance().getConfigDir().resolve("noctis").resolve("command-log.txt");
                String line = (stamp.on() ? "[" + LocalDateTime.now().withNano(0) + "] " : "") + "/" + command + System.lineSeparator();
                Files.writeString(f, line, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (IOException e) { NoctisClient.LOG.warn("CommandLogger write failed: {}", e.toString()); }
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Export extends ActionModule {
        public Export() { super("Export", "Writes a plain-text module status report and the active profile to config/noctis/export/.", Category.MISC, Status.IMPLEMENTED); }
        @Override protected void run() {
            try {
                Path dir = FabricLoader.getInstance().getConfigDir().resolve("noctis").resolve("export");
                Files.createDirectories(dir);
                StringBuilder sb = new StringBuilder("# Noctis module status\n\nGenerated " + LocalDateTime.now().withNano(0) + ". No module is runtime-verified unless the README checklist says so.\n");
                for (Category c : Category.values()) {
                    sb.append("\n## ").append(c.label).append('\n');
                    for (Module m : ModuleManager.in(c)) sb.append("- ").append(m.name).append(" [").append(m.status.label).append("] ").append(m.description).append('\n');
                }
                Files.writeString(dir.resolve("status.md"), sb.toString(), StandardCharsets.UTF_8);
                ConfigManager.export();
                Inv.say("Exported status.md and profile to config/noctis/.");
            } catch (IOException e) { Inv.say("Export failed: " + e.getMessage()); }
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class TeamsModule extends Module {
        private final StrSetting friends = add(new StrSetting("Friends", "Comma-separated player names AimAssist/TriggerBot will ignore", "", 256));
        public TeamsModule() { super("Teams", "Client-side friends list. Listed players are skipped by targeting modules.", Category.MISC, Status.IMPLEMENTED); }
        public boolean contains(String name) {
            return Arrays.stream(friends.get().split(",")).map(String::trim).anyMatch(s -> !s.isEmpty() && s.equalsIgnoreCase(name));
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class SelfDestruct extends ActionModule {
        public SelfDestruct() { super("SelfDestruct", "Disables every module, closes the GUI and clears temporary in-memory state. Deletes no files and touches no logs.", Category.MISC, Status.IMPLEMENTED); }
        @Override protected void run() {
            ModuleManager.disableAll();
            ModuleManager.clearTransient();
            if (mc.currentScreen instanceof ClickGuiScreen) mc.setScreen(null);
            Inv.say("All modules disabled and temporary state cleared.");
        }
    }

    // ------------------------------------------------------------------------------------------
    /** Records what changed in your own inventory each time you close a container. Local file only. */
    public static final class Transactions extends Module {
        private final BoolSetting chat = add(new BoolSetting("Show in chat", "Also print the summary to your chat (client-side only)", false));
        private java.util.Map<String, Integer> before;
        public Transactions() { super("Transactions", "Logs the net item changes in your inventory after each container (chest, furnace, ...) you close, to config/noctis/transactions.log. Local file only.", Category.MISC, Status.IMPLEMENTED); }

        private java.util.Map<String, Integer> snapshot() {
            java.util.Map<String, Integer> m = new java.util.TreeMap<>();
            var inv = player().getInventory();
            for (int i = 0; i < inv.size(); i++) {
                var s = inv.getStack(i);
                if (!s.isEmpty()) m.merge(net.minecraft.registry.Registries.ITEM.getId(s.getItem()).toString(), s.getCount(), Integer::sum);
            }
            return m;
        }

        @Override protected void onTick() {
            boolean open = player().currentScreenHandler != player().playerScreenHandler;
            if (open && before == null) before = snapshot();
            else if (!open && before != null) { finish(); before = null; }
        }
        @Override protected void onDisable() { before = null; }

        private void finish() {
            var after = snapshot();
            var keys = new java.util.TreeSet<>(before.keySet());
            keys.addAll(after.keySet());
            StringBuilder sb = new StringBuilder();
            for (String k : keys) {
                int d = after.getOrDefault(k, 0) - before.getOrDefault(k, 0);
                if (d != 0) sb.append(sb.length() == 0 ? "" : ", ").append(d > 0 ? "+" : "").append(d).append(' ').append(k);
            }
            if (sb.length() == 0) return;
            try {
                Path f = FabricLoader.getInstance().getConfigDir().resolve("noctis").resolve("transactions.log");
                Files.createDirectories(f.getParent());
                Files.writeString(f, "[" + LocalDateTime.now().withNano(0) + "] " + sb + System.lineSeparator(), StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (IOException e) { NoctisClient.LOG.warn("Transactions write failed: {}", e.toString()); }
            if (chat.on()) Inv.say("Transaction: " + sb);
        }
    }
}
