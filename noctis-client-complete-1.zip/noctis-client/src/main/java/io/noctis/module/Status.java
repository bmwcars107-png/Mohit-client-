package io.noctis.module;

/** Honest implementation status shown in the GUI for every module. */
public enum Status {
    IMPLEMENTED("Implemented", "Code written for this module (see README: nothing is runtime-verified yet)."),
    PRIVATE_TEST("Own world only", "Implemented for your own worlds only: singleplayer, and your own LAN world while friends are in it (self-only modules; anything that could affect other players stays solo-only). Never runs on a remote server."),
    PLANNED("Planned", "Not implemented in this build. Cannot be enabled."),
    BLOCKED("Not provided", "Deliberately not provided: it would automate combat, alter hit registration, expose hidden information or bypass server rules.");

    public final String label, help;
    Status(String label, String help) { this.label = label; this.help = help; }
}
