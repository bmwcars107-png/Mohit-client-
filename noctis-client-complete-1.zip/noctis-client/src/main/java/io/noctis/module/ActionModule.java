package io.noctis.module;

/** One-shot module: toggling it (button or keybind) runs {@link #run()} once. */
public abstract class ActionModule extends Module {
    protected ActionModule(String name, String description, Category category, Status status) {
        super(name, description, category, status);
        this.action = true;
    }

    protected abstract void run();

    @Override protected final void onEnable() {
        try { run(); } finally { setEnabled(false); }
    }
}
