package io.noctis.module.impl;

import io.noctis.mixin.InteractionManagerAccessor;
import io.noctis.mixin.MinecraftClientAccessor;
import io.noctis.module.*;
import io.noctis.module.Module;
import io.noctis.setting.BoolSetting;
import io.noctis.setting.NumSetting;
import net.minecraft.block.BlockState;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

import static io.noctis.module.impl.Modules.unavailable;

public final class PlayerModules {
    private PlayerModules() {}

    static void register() {
        ModuleManager.register(new AutoTool());
        ModuleManager.register(new AutoTotem());
        ModuleManager.register(new TotemOffhand());
        ModuleManager.register(new FastPlace());
        ModuleManager.register(new NoBreakDelay());
        ModuleManager.register(new FastEXP());
        ModuleManager.register(new Replenish());
        ModuleManager.register(new ElytraSwap());
        ModuleManager.register(new TotemDoubleHand());
        ModuleManager.register(new PotRefill());
        ModuleManager.register(new TotemRefill());
        ModuleManager.register(new SmartPot());

        Category c = Category.PLAYER;
        unavailable(c, Status.BLOCKED, "AntiTrap", "Automatic block placement around traps.", "Reviewed: automatic block placement against traps reacts to other players and has no specified behaviour; the only workable reading is PvP automation. Deliberately unavailable.");
        unavailable(c, Status.BLOCKED, "AutoLava", "Automated lava placement.", "Reviewed: automated lava placement is a griefing / PvP trap tool and no single-player use case was identified. Deliberately unavailable.");
        unavailable(c, Status.BLOCKED, "BlockBruteforcer", "Probes blocks repeatedly.", "Reviewed: repeatedly probing blocks has no specified behaviour and no legitimate use was identified. Deliberately unavailable.");
    }

    // ------------------------------------------------------------------------------------------
    public static final class AutoTool extends Module {
        private final BoolSetting back = add(new BoolSetting("Switch back", "Return to the previous slot afterwards", true));
        private int previous = -1;
        public AutoTool() { super("AutoTool", "Picks the fastest hotbar tool for the block you are mining. Check the rules of any server before using it.", Category.PLAYER, Status.IMPLEMENTED); }

        @Override protected void onTick() {
            if (mc.options.attackKey.isPressed() && mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
                BlockState st = mc.world.getBlockState(hit.getBlockPos());
                int bestSlot = -1;
                float best = player().getInventory().getStack(Inv.selected()).getMiningSpeedMultiplier(st);
                for (int i = 0; i < 9; i++) {
                    float sp = player().getInventory().getStack(i).getMiningSpeedMultiplier(st);
                    if (sp > best + 0.01f) { best = sp; bestSlot = i; }
                }
                if (bestSlot >= 0) { if (previous < 0) previous = Inv.selected(); Inv.select(bestSlot); }
            } else if (previous >= 0) {
                if (back.on()) Inv.select(previous);
                previous = -1;
            }
        }
        @Override protected void onDisable() { if (previous >= 0 && back.on()) Inv.select(previous); previous = -1; }
    }

    /** Swap a totem into the offhand using the vanilla inventory swap click (offhand = button 40). */
    static boolean swapTotemToOffhand() {
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        var p = mc.player;
        if (p == null || mc.interactionManager == null) return false;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return false;
        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, Inv.handlerSlot(i), 40, SlotActionType.SWAP, p);
                return true;
            }
        }
        return false;
    }

    public static final class AutoTotem extends Module {
        private final NumSetting delay = add(new NumSetting("Delay", "Ticks between swaps", 3, 0, 20, 1));
        private int wait;
        public AutoTotem() { super("AutoTotem", "Keeps a totem of undying in your offhand. Singleplayer test worlds only.", Category.PLAYER, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            if (wait-- > 0 || mc.currentScreen != null) return;
            if (swapTotemToOffhand()) wait = delay.intVal();
        }
    }

    public static final class TotemOffhand extends ActionModule {
        public TotemOffhand() { super("TotemOffhand", "Moves one totem to your offhand when triggered (bind a key). User-triggered shortcut.", Category.PLAYER, Status.IMPLEMENTED); }
        @Override protected void run() {
            if (inGame() && !swapTotemToOffhand()) Inv.say("TotemOffhand: no totem found (or one is already in your offhand).");
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class FastPlace extends Module {
        private final NumSetting delay = add(new NumSetting("Delay", "Use cooldown in ticks (vanilla is 4)", 1, 0, 4, 1));
        private final BoolSetting blocksOnly = add(new BoolSetting("Blocks only", "Only while holding a block", true));
        public FastPlace() { super("FastPlace", "Shortens the delay between placing / using items. Singleplayer test worlds only.", Category.PLAYER, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            if (blocksOnly.on() && !(player().getMainHandStack().getItem() instanceof BlockItem)) return;
            var acc = (MinecraftClientAccessor) mc;
            if (acc.noctis$getItemUseCooldown() > delay.intVal()) acc.noctis$setItemUseCooldown(delay.intVal());
        }
    }

    public static final class NoBreakDelay extends Module {
        public NoBreakDelay() { super("NoBreakDelay", "Removes the delay between breaking blocks. Singleplayer test worlds only.", Category.PLAYER, Status.PRIVATE_TEST); }
        @Override protected void onTick() { ((InteractionManagerAccessor) mc.interactionManager).noctis$setBlockBreakingCooldown(0); }
    }

    public static final class FastEXP extends Module {
        public FastEXP() { super("FastEXP", "No cooldown between throwing experience bottles. Singleplayer test worlds only.", Category.PLAYER, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            if (player().getMainHandStack().isOf(Items.EXPERIENCE_BOTTLE)) ((MinecraftClientAccessor) mc).noctis$setItemUseCooldown(0);
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class Replenish extends Module {
        private final NumSetting threshold = add(new NumSetting("Refill at", "Refill a hotbar stack when it has this many items or fewer", 8, 1, 32, 1));
        private final NumSetting delay = add(new NumSetting("Delay", "Ticks between refills", 4, 1, 20, 1));
        private int wait;
        public Replenish() { super("Replenish", "Refills stackable hotbar items from your inventory. Singleplayer test worlds only.", Category.PLAYER, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            if (wait-- > 0 || mc.currentScreen != null) return;
            var p = player();
            for (int h = 0; h < 9; h++) {
                ItemStack hs = p.getInventory().getStack(h);
                if (hs.isEmpty() || !hs.isStackable() || hs.getCount() > threshold.intVal() || hs.getCount() >= hs.getMaxCount()) continue;
                for (int i = 9; i < 36; i++) {
                    ItemStack is = p.getInventory().getStack(i);
                    if (!is.isEmpty() && ItemStack.areItemsAndComponentsEqual(hs, is)) {
                        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, Inv.handlerSlot(i), 0, SlotActionType.QUICK_MOVE, p);
                        wait = delay.intVal();
                        return;
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    /** Swap chestplate and elytra: if an elytra is worn, wear the best chestplate, otherwise wear an elytra. */
    public static final class ElytraSwap extends ActionModule {
        public ElytraSwap() { super("ElytraSwap", "Swaps your worn chestplate and an elytra from your inventory when triggered (bind a key). User-triggered shortcut.", Category.PLAYER, Status.IMPLEMENTED); }
        @Override protected void run() {
            if (!inGame()) return;
            var p = player();
            boolean wearingElytra = p.getEquippedStack(net.minecraft.entity.EquipmentSlot.CHEST).isOf(Items.ELYTRA);
            int found = -1;
            for (int i = 0; i < 36 && found < 0; i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (wearingElytra ? s.isIn(net.minecraft.registry.tag.ItemTags.CHEST_ARMOR) : s.isOf(Items.ELYTRA)) found = i;
            }
            if (found < 0) { Inv.say("ElytraSwap: no " + (wearingElytra ? "chestplate" : "elytra") + " in your inventory."); return; }
            Inv.swapSlots(Inv.handlerSlot(found), 6); // 6 = chest armor slot of the player screen handler
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class TotemDoubleHand extends ActionModule {
        public TotemDoubleHand() { super("TotemDoubleHand", "Puts a totem in your offhand and in your selected hotbar slot when triggered (bind a key). Needs two totems. User-triggered shortcut.", Category.PLAYER, Status.IMPLEMENTED); }
        @Override protected void run() {
            if (!inGame()) return;
            var p = player();
            swapTotemToOffhand();
            if (!p.getMainHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                for (int i = 9; i < 36; i++) {
                    if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, Inv.handlerSlot(i), Inv.selected(), SlotActionType.SWAP, p);
                        return;
                    }
                }
                Inv.say("TotemDoubleHand: no second totem found for your main hand.");
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class PotRefill extends ActionModule {
        private final NumSetting max = add(new NumSetting("Max potions", "Fill at most this many empty hotbar slots", 3, 1, 9, 1));
        private final io.noctis.setting.ModeSetting kind = add(new io.noctis.setting.ModeSetting("Type", "Which potions to pull from your inventory", "Splash", "Splash", "Drinkable", "Any"));
        public PotRefill() { super("PotRefill", "Moves potions from your inventory into empty hotbar slots when triggered (bind a key). User-triggered shortcut.", Category.PLAYER, Status.IMPLEMENTED); }
        @Override protected void run() {
            if (!inGame()) return;
            var p = player();
            int moved = 0;
            for (int h = 0; h < 9 && moved < max.intVal(); h++) {
                if (!p.getInventory().getStack(h).isEmpty()) continue;
                for (int i = 9; i < 36; i++) {
                    ItemStack s = p.getInventory().getStack(i);
                    boolean ok = switch (kind.get()) {
                        case "Splash" -> s.isOf(Items.SPLASH_POTION);
                        case "Drinkable" -> s.isOf(Items.POTION);
                        default -> s.isOf(Items.SPLASH_POTION) || s.isOf(Items.POTION);
                    };
                    if (ok) {
                        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, Inv.handlerSlot(i), h, SlotActionType.SWAP, p);
                        moved++;
                        break;
                    }
                }
            }
            if (moved == 0) Inv.say("PotRefill: nothing to move (no empty hotbar slot or no matching potion).");
        }
    }

    // ------------------------------------------------------------------------------------------
    public static final class TotemRefill extends Module {
        private final NumSetting slot = add(new NumSetting("Hotbar slot", "Hotbar slot (1-9) that is kept stocked with a totem", 9, 1, 9, 1));
        private final NumSetting delay = add(new NumSetting("Delay", "Ticks between refills", 10, 1, 40, 1));
        private int wait;
        public TotemRefill() { super("TotemRefill", "Keeps one hotbar slot stocked with a totem from your inventory. Singleplayer test worlds only.", Category.PLAYER, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            if (wait-- > 0 || mc.currentScreen != null) return;
            var p = player();
            int target = slot.intVal() - 1;
            if (p.getInventory().getStack(target).isOf(Items.TOTEM_OF_UNDYING)) return;
            for (int i = 9; i < 36; i++) {
                if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                    mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, Inv.handlerSlot(i), target, SlotActionType.SWAP, p);
                    wait = delay.intVal();
                    return;
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    /** Throws a splash healing potion at your feet when health is low. Detected by item name ("... of Healing"). */
    public static final class SmartPot extends Module {
        private final NumSetting health = add(new NumSetting("Health", "Throw when health (half-hearts) is at or below this", 8, 2, 19, 1));
        private final NumSetting delay = add(new NumSetting("Delay", "Ticks between throws", 20, 5, 100, 1));
        private int wait;
        public SmartPot() { super("SmartPot", "Throws a splash potion of healing from your hotbar at your feet when health is low. Singleplayer test worlds only.", Category.PLAYER, Status.PRIVATE_TEST); }
        @Override protected void onTick() {
            var p = player();
            if (wait-- > 0 || mc.currentScreen != null || p.getHealth() > health.val()) return;
            int slot = Inv.hotbar(s -> s.isOf(Items.SPLASH_POTION) && s.getName().getString().toLowerCase(java.util.Locale.ROOT).contains("healing"));
            if (slot < 0) return;
            int prev = Inv.selected();
            float pitch = p.getPitch();
            Inv.select(slot);
            p.setPitch(90f);
            mc.interactionManager.interactItem(p, net.minecraft.util.Hand.MAIN_HAND);
            p.setPitch(pitch);
            Inv.select(prev);
            wait = delay.intVal();
        }
    }
}
