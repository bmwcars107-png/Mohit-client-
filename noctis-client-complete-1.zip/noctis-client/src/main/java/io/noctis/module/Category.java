package io.noctis.module;

public enum Category {
    COMBAT("Combat"), MOVEMENT("Movement"), PLAYER("Player"), MACROS("Macros"),
    RENDER("Render"), HUD("HUD"), MISC("Misc");

    public final String label;
    Category(String label) { this.label = label; }
}
