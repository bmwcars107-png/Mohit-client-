package io.noctis.module;

/** A catalogue entry that is not implemented. It is listed honestly and can never be enabled. */
public final class UnavailableModule extends Module {
    private final String reason;

    public UnavailableModule(String name, Category cat, Status status, String description, String reason) {
        super(name, description, cat, status);
        if (status != Status.PLANNED && status != Status.BLOCKED)
            throw new IllegalArgumentException("UnavailableModule must be PLANNED or BLOCKED");
        this.reason = reason;
    }

    @Override public String blockedReason() { return status.label + ": " + reason; }
}
