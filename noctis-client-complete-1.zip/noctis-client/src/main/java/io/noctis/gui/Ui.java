package io.noctis.gui;

import net.minecraft.client.gui.DrawContext;

/** Small reusable widgets shared by the ClickGUI and the HUD editor. */
final class Ui {
    private Ui() {}

    static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    static void button(DrawContext c, Regions rg, int x, int y, int w, int h, String label, double mx, double my,
                       float alpha, boolean accent, Regions.Press p) {
        boolean hot = in(mx, my, x, y, w, h) && rg.visible(mx, my);
        int base = accent ? Render2D.mix(Theme.PANEL2, Theme.primary(), 0.55f) : Theme.PANEL2;
        Render2D.rrect(c, x, y, w, h, 4, Render2D.a(hot ? Render2D.mix(base, 0xFFFFFFFF, 0.12f) : base, alpha));
        Render2D.centered(c, label, x + w / 2, y + (h - 8) / 2, Render2D.a(Theme.TEXT, alpha));
        rg.add(x, y, w, h, p, null);
    }

    static void toggle(DrawContext c, int x, int y, int w, int h, float t, float alpha, int onColor) {
        Render2D.rrect(c, x, y, w, h, h / 2, Render2D.a(Render2D.mix(Theme.OFF, onColor, t), alpha));
        int k = h - 4;
        Render2D.rrect(c, x + 2 + Math.round((w - h) * t), y + 2, k, k, k / 2, Render2D.a(Render2D.mix(0xFFB9BECB, 0xFFFFFFFF, t), alpha));
    }

    static float ease(float t) { float u = 1f - Math.max(0f, Math.min(1f, t)); return 1f - u * u * u; }
}
