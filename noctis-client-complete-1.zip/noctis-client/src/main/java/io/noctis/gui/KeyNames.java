package io.noctis.gui;

import org.lwjgl.glfw.GLFW;

public final class KeyNames {
    private KeyNames() {}

    public static String of(int key) {
        if (key < 0) return "None";
        switch (key) {
            case 32: return "Space";   case 256: return "Esc";    case 257: return "Enter";  case 258: return "Tab";
            case 259: return "Backspace"; case 260: return "Insert"; case 261: return "Delete";
            case 262: return "Right";  case 263: return "Left";   case 264: return "Down";   case 265: return "Up";
            case 266: return "PgUp";   case 267: return "PgDn";   case 268: return "Home";   case 269: return "End";
            case 280: return "Caps";   case 340: return "LShift"; case 341: return "LCtrl";  case 342: return "LAlt";
            case 344: return "RShift"; case 345: return "RCtrl";  case 346: return "RAlt";
            default: break;
        }
        if (key >= 290 && key <= 301) return "F" + (key - 289);
        if (key >= 320 && key <= 329) return "Num" + (key - 320);
        String n = GLFW.glfwGetKeyName(key, 0);
        return n != null ? n.toUpperCase() : "Key" + key;
    }
}
