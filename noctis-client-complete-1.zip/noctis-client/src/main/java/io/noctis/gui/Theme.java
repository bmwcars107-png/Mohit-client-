package io.noctis.gui;

import io.noctis.module.impl.MiscModules;

/** Fixed dark palette plus accents driven by the ClientThemes module. */
public final class Theme {
    private Theme() {}

    public static final int BG = 0xFF0B0B11, PANEL = 0xFF12121A, PANEL2 = 0xFF181823, ROW = 0xFF0F0F17,
            HOVER = 0xFF222234, OFF = 0xFF2A2A3A, TEXT = 0xFFECEEF4, DIM = 0xFF8B90A3, SILVER = 0xFFC4C9D4,
            WARN = 0xFFE5486A;

    public static int primary() { return MiscModules.THEMES == null ? 0xFF8B5CF6 : MiscModules.THEMES.primary(); }
    public static int secondary() { return MiscModules.THEMES == null ? 0xFFE11D48 : MiscModules.THEMES.secondary(); }
    public static float windowOpacity() { return MiscModules.THEMES == null ? 0.96f : MiscModules.THEMES.windowOpacity(); }
}
