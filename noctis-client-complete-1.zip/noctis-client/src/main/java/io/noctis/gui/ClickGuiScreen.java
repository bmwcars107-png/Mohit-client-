package io.noctis.gui;

import io.noctis.config.ConfigManager;
import io.noctis.module.*;
import io.noctis.module.Module;
import io.noctis.module.impl.MiscModules;
import io.noctis.setting.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

import java.util.*;

/**
 * The Noctis ClickGUI. Immediate-mode: every frame the layout is drawn and hit regions are rebuilt,
 * so rendering, input handling and state stay in one small loop. Settings widgets only call
 * Setting#set / Module#toggle, which keeps game logic and persistence out of this class.
 */
public final class ClickGuiScreen extends Screen {
    private static final int SB = 128, HEAD = 44;
    private static int wx = Integer.MIN_VALUE, wy, ww = 640, wh = 410;

    private enum Page { MODULES, PROFILES }
    private enum Focus { NONE, SEARCH, STRING, PROFILE }

    private final Regions rg = new Regions();
    private final Map<Object, Float> hov = new HashMap<>();

    private Category cat = Category.COMBAT;
    private Page page = Page.MODULES;
    private Focus focus = Focus.NONE;
    private String search = "", text = "", newProfile = "";
    private Setting<?> editing, dropdown, picker;
    private float[] hsv = {0, 1, 1};
    private Module expanded, binding;
    private float open, scroll, target, al;
    private boolean closing;
    private long last = System.nanoTime();
    private int contentH, viewH, dragOffX, dragOffY;
    private String toast = "";
    private long toastUntil;

    public ClickGuiScreen() { super(Text.literal("Noctis")); }

    @Override protected void init() {
        if (wx == Integer.MIN_VALUE) { wx = (width - ww) / 2; wy = (height - wh) / 2; }
        clampWindow();
    }

    private void clampWindow() {
        ww = Math.max(480, Math.min(ww, width - 12));
        wh = Math.max(300, Math.min(wh, height - 12));
        wx = Math.max(0, Math.min(wx, width - ww));
        wy = Math.max(0, Math.min(wy, height - wh));
    }

    @Override public boolean shouldPause() { return false; }

    private int A(int c) { return Render2D.a(c, al); }

    private float hv(Object key, boolean on, float dt) {
        float v = hov.getOrDefault(key, 0f);
        v += ((on ? 1f : 0f) - v) * Math.min(1f, dt * 14f);
        hov.put(key, v);
        return v;
    }

    private void notice(String s) { toast = s; toastUntil = System.currentTimeMillis() + 3200; }

    // =============================================================================================
    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        float spd = MiscModules.ClickGui.INSTANCE == null ? 1f : MiscModules.ClickGui.INSTANCE.animSpeed.floatVal();
        if (closing) {
            open -= dt * 5f * spd;
            if (open <= 0f) { if (client != null) client.setScreen(null); return; }
        } else open = Math.min(1f, open + dt * 5f * spd);
        al = Ui.ease(open);
        clampWindow();
        target = Math.max(0, Math.min(target, Math.max(0, contentH - viewH)));
        scroll += (target - scroll) * Math.min(1f, dt * 14f);

        rg.clear();
        rg.clearClip();
        c.fill(0, 0, width, height, Render2D.a(0xFF000000, 0.5f * al));

        int x = wx, y = wy + Math.round((1f - al) * 16f), w = ww, h = wh;
        for (int i = 4; i >= 1; i--) Render2D.rrect(c, x - i * 2, y - i * 2 + 3, w + i * 4, h + i * 4, 8 + i, Render2D.a(0xFF000000, 0.07f * al));
        Render2D.rrect(c, x, y, w, h, 8, Render2D.a(Theme.BG, al * Theme.windowOpacity()));
        Render2D.rrect(c, x, y, SB, h, 8, A(Theme.PANEL));
        c.fill(x + SB - 8, y, x + SB, y + h, A(Theme.PANEL));
        Render2D.hGradient(c, x + 8, y, w - 16, 2, A(Theme.primary()), A(Theme.secondary()));

        // window drag (added first so everything else sits on top)
        rg.add(x, y, w, HEAD, (px, py, b) -> { dragOffX = (int) px - wx; dragOffY = (int) py - wy; },
                (px, py) -> { wx = (int) px - dragOffX; wy = (int) py - dragOffY; });

        drawSidebar(c, x, y, h, mx, my, dt);
        if (page == Page.MODULES) drawModulesPage(c, x, y, w, h, mx, my, dt);
        else drawProfilesPage(c, x, y, w, h, mx, my, dt);

        // resize grip
        for (int i = 0; i < 3; i++) c.fill(x + w - 5 - i * 4, y + h - 4, x + w - 3 - i * 4, y + h - 2, A(Theme.DIM));
        rg.add(x + w - 16, y + h - 16, 16, 16, null, (px, py) -> { ww = (int) px - wx + 4; wh = (int) py - wy + 4; });

        if (System.currentTimeMillis() < toastUntil && !toast.isEmpty()) {
            int tw = Render2D.tw(toast) + 20, tx = x + SB + (w - SB - tw) / 2, ty = y + h - 30;
            Render2D.rrect(c, tx, ty, tw, 18, 6, A(0xF0241824));
            Render2D.outline(c, tx, ty, tw, 18, A(Render2D.mix(Theme.WARN, 0xFF000000, 0.35f)));
            Render2D.text(c, toast, tx + 10, ty + 5, A(Theme.TEXT));
        }
    }

    // =============================================================================================
    private void drawSidebar(DrawContext c, int x, int y, int h, int mx, int my, float dt) {
        Render2D.logo(c, x + 24, y + 22, 10, A(Theme.primary()), A(Theme.secondary()), 1f);
        String word = "NOCTIS";
        int tx = x + 42;
        for (int i = 0; i < word.length(); i++) {
            String ch = String.valueOf(word.charAt(i));
            Render2D.text(c, ch, tx, y + 13, A(Render2D.mix(Theme.primary(), Theme.SILVER, i / 5f)));
            tx += Render2D.tw(ch);
        }
        Render2D.text(c, "CLIENT", x + 42, y + 24, A(Theme.DIM));

        int iy = y + HEAD + 6;
        for (Category k : Category.values()) {
            final Category kk = k;
            nav(c, k, k.ordinal(), k.label, page == Page.MODULES && cat == k && search.isEmpty(), x + 8, iy, SB - 16, 24, mx, my, dt,
                    () -> { cat = kk; page = Page.MODULES; search = ""; resetView(); });
            int on = 0;
            for (Module m : ModuleManager.in(k)) if (m.isEnabled() && !m.action) on++;
            if (on > 0) Render2D.text(c, String.valueOf(on), x + SB - 24, iy + 8, A(Theme.primary()));
            iy += 26;
        }
        iy += 8;
        c.fill(x + 14, iy - 5, x + SB - 14, iy - 4, A(Theme.OFF));
        nav(c, "profiles", 7, "Profiles", page == Page.PROFILES, x + 8, iy, SB - 16, 24, mx, my, dt, () -> { page = Page.PROFILES; resetView(); });
        iy += 26;
        nav(c, "hud", 5, "HUD Editor", false, x + 8, iy, SB - 16, 24, mx, my, dt, () -> { if (client != null) client.setScreen(new HudEditorScreen(this)); });

        String p = ConfigManager.active();
        Render2D.text(c, "Profile", x + 14, y + wh - 32, A(Theme.DIM));
        Render2D.text(c, Render2D.trim(p, SB - 28), x + 14, y + wh - 21, A(Theme.SILVER));
        if (ConfigManager.isPrivateTest(p)) Render2D.text(c, "PRIVATE TEST", x + 14, y + wh - 11, A(Theme.WARN));
    }

    private void nav(DrawContext c, Object key, int icon, String label, boolean sel, int x, int y, int w, int h,
                     int mx, int my, float dt, Runnable go) {
        float hv = hv(key, Ui.in(mx, my, x, y, w, h), dt), selT = hv("sel:" + key, sel, dt);
        Render2D.rrect(c, x, y, w, h, 5, A(Render2D.mix(Render2D.mix(Theme.PANEL, Theme.HOVER, hv * 0.6f), Theme.PANEL2, selT)));
        if (selT > 0.02f) Render2D.rrect(c, x, y + 5, 2, h - 10, 1, A(Render2D.mix(Theme.PANEL2, Theme.primary(), selT)));
        int col = Render2D.mix(Theme.DIM, Theme.TEXT, Math.max(hv * 0.7f, selT));
        Render2D.icon(c, icon, x + 10, y + 5, 2, A(sel ? Theme.primary() : col));
        Render2D.text(c, label, x + 31, y + 8, A(col));
        rg.add(x, y, w, h, (px, py, b) -> go.run(), null);
    }

    private void resetView() { scroll = target = 0; expanded = null; dropdown = null; picker = null; binding = null; editing = null; focus = Focus.NONE; }

    // =============================================================================================
    private List<Module> list() {
        List<Module> out = new ArrayList<>();
        String q = search.trim().toLowerCase(Locale.ROOT);
        for (Module m : ModuleManager.all()) {
            if (q.isEmpty() ? m.category == cat : (m.name.toLowerCase(Locale.ROOT).contains(q) || m.description.toLowerCase(Locale.ROOT).contains(q))) out.add(m);
        }
        out.sort(Comparator.<Module>comparingInt(m -> m.group.isEmpty() ? 0 : 1)
                .thenComparingInt(m -> (m.status == Status.PLANNED || m.status == Status.BLOCKED) ? 1 : 0)
                .thenComparing(m -> m.name));
        return out;
    }

    private void drawModulesPage(DrawContext c, int x, int y, int w, int h, int mx, int my, float dt) {
        int fx = x + SB + 14, fw = w - SB - 28;
        // search bar
        boolean sf = focus == Focus.SEARCH;
        Render2D.rrect(c, fx, y + 12, fw, 20, 5, A(sf ? Theme.PANEL2 : Theme.ROW));
        if (sf) Render2D.outline(c, fx, y + 12, fw, 20, A(Render2D.mix(Theme.PANEL2, Theme.primary(), 0.7f)));
        String shown = search.isEmpty() && !sf ? "Search modules..." : search + (sf && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        Render2D.text(c, shown, fx + 8, y + 18, A(search.isEmpty() ? Theme.DIM : Theme.TEXT));
        rg.add(fx, y + 12, fw, 20, (px, py, b) -> { focus = Focus.SEARCH; editing = null; }, null);

        List<Module> mods = list();
        int cx = fx, cy = y + HEAD + 18, cw = fw;
        viewH = h - HEAD - 18 - 14;
        String title = search.isEmpty() ? cat.label : "Search results";
        Render2D.text(c, title, cx, y + HEAD + 3, A(Theme.SILVER));
        String cnt = mods.size() + (mods.size() == 1 ? " module" : " modules");
        Render2D.text(c, cnt, cx + cw - Render2D.tw(cnt), y + HEAD + 3, A(Theme.DIM));

        rg.setClip(cx, cy, cx + cw, cy + viewH);
        c.enableScissor(cx, cy, cx + cw, cy + viewH);
        int cur = cy - Math.round(scroll);
        String lastGroup = "";
        for (Module m : mods) {
            if (!m.group.isEmpty() && !m.group.equals(lastGroup)) {
                lastGroup = m.group;
                Render2D.text(c, m.group.toUpperCase(Locale.ROOT) + "  -  user-configured server macros", cx + 2, cur + 3, A(Theme.DIM));
                cur += 16;
            }
            cur = drawModule(c, m, cx, cur, cw, mx, my, dt) + 6;
        }
        if (mods.isEmpty()) Render2D.text(c, "Nothing matches your search.", cx + 4, cy + 6, A(Theme.DIM));
        contentH = cur + Math.round(scroll) - cy;
        c.disableScissor();
        rg.clearClip();

        if (contentH > viewH) {                                    // scrollbar
            int bh = Math.max(20, viewH * viewH / contentH);
            int by = cy + Math.round((viewH - bh) * (scroll / Math.max(1f, contentH - viewH)));
            Render2D.rrect(c, cx + cw + 4, by, 3, bh, 1, A(Render2D.mix(Theme.OFF, Theme.primary(), 0.6f)));
        }
    }

    private int drawModule(DrawContext c, Module m, int x, int y, int w, int mx, int my, float dt) {
        final int h = 34;
        boolean dead = m.status == Status.PLANNED || m.status == Status.BLOCKED;
        boolean on = m.isEnabled();
        m.anim += ((on ? 1f : 0f) - m.anim) * Math.min(1f, dt * 12f);
        boolean hot = Ui.in(mx, my, x, y, w, h) && rg.visible(mx, my);
        float hv = hv(m, hot, dt);
        Render2D.rrect(c, x, y, w, h, 5, A(Render2D.mix(Theme.PANEL2, Theme.HOVER, hv * 0.55f)));
        if (m.anim > 0.02f) Render2D.rrect(c, x, y + 6, 2, h - 12, 1, A(Render2D.mix(Theme.PANEL2, Theme.primary(), m.anim)));

        int nameCol = dead ? Theme.DIM : Render2D.mix(Theme.TEXT, 0xFFFFFFFF, m.anim);
        Render2D.text(c, m.name, x + 12, y + 7, A(nameCol));
        int bx = x + 12 + Render2D.tw(m.name) + 6;
        if (m.status != Status.IMPLEMENTED) {
            String badge = m.status == Status.PRIVATE_TEST ? "PRIVATE TEST" : m.status == Status.PLANNED ? "PLANNED" : "NOT PROVIDED";
            int bw = Render2D.tw(badge) * 7 / 10 + 8;
            int bc = m.status == Status.PRIVATE_TEST ? Render2D.mix(Theme.PANEL2, Theme.WARN, 0.35f) : Theme.OFF;
            Render2D.rrect(c, bx, y + 6, bw, 11, 3, A(bc));
            Render2D.push(c, bx + 4, y + 8, 0.7f);
            Render2D.text(c, badge, 0, 0, A(m.status == Status.PRIVATE_TEST ? 0xFFF1B7C4 : Theme.DIM));
            Render2D.pop(c);
        }
        if (m.key() > 0) {
            String k = "[" + KeyNames.of(m.key()) + "]";
            Render2D.text(c, k, x + w - 78 - Render2D.tw(k), y + 7, A(Theme.DIM));
        }
        if (MiscModules.ClickGui.INSTANCE == null || MiscModules.ClickGui.INSTANCE.descriptions.on())
            Render2D.text(c, Render2D.trim(m.description, w - 90), x + 12, y + 20, A(Render2D.mix(Theme.DIM, Theme.BG, 0.15f)));

        // regions: row first, then control widgets on top
        rg.add(x, y, w - 18, h, (px, py, b) -> { if (b == 0) toggleModule(m); else if (b == 1) expand(m); }, null);
        if (m.action && !dead) Ui.button(c, rg, x + w - 66, y + 9, 44, 16, "RUN", mx, my, al, false, (px, py, b) -> toggleModule(m));
        else if (!dead) {
            Ui.toggle(c, x + w - 56, y + 10, 34, 16, m.anim, al, Theme.primary());
            rg.add(x + w - 56, y + 10, 34, 16, (px, py, b) -> toggleModule(m), null);
        } else Render2D.text(c, "locked", x + w - 50, y + 13, A(Theme.OFF));
        Render2D.text(c, expanded == m ? "-" : "+", x + w - 12, y + 13, A(Theme.DIM));
        rg.add(x + w - 18, y, 18, h, (px, py, b) -> expand(m), null);

        int cur = y + h;
        if (expanded == m) cur = drawExpanded(c, m, x + 8, cur + 3, w - 16, mx, my, dt);
        return cur;
    }

    private void toggleModule(Module m) {
        if (!m.toggle() && !m.notice.isEmpty()) notice(m.name + ": " + m.notice);
        if (m.action && m.isEnabled()) { /* run() already executed and switched itself off */ }
    }

    private void expand(Module m) {
        expanded = expanded == m ? null : m;
        dropdown = null; picker = null; editing = null; binding = null; focus = Focus.NONE;
    }

    // ---------------------------------------------------------------------------------------------
    private int wrap(DrawContext c, String s, int x, int y, int w, int col) {
        int lines = 0;
        while (!s.isEmpty() && lines < 3) {
            String l = Render2D.trim(s, w);
            if (l.isEmpty()) break;
            if (l.length() < s.length()) { int sp = l.lastIndexOf(' '); if (sp > 8) l = l.substring(0, sp); }
            Render2D.text(c, l, x, y + lines * 10, col);
            s = s.substring(l.length()).trim();
            lines++;
        }
        return lines * 10;
    }

    private int drawExpanded(DrawContext c, Module m, int x, int y, int w, int mx, int my, float dt) {
        int cur = y;
        int used = wrap(c, "Status: " + m.status.label + ". " + m.status.help, x + 2, cur, w - 4, A(Theme.DIM));
        cur += used + 4;
        if (m.status == Status.PLANNED || m.status == Status.BLOCKED) {
            String r = m.blockedReason();
            cur += wrap(c, r == null ? "" : r, x + 2, cur, w - 4, A(Theme.SILVER)) + 4;
            return cur;
        }
        if (!m.lastError.isEmpty()) { Render2D.text(c, "Last error: " + m.lastError, x + 2, cur, A(Theme.WARN)); cur += 12; }

        // keybind row
        final int rh = 20;
        float hv = hv(m.name + ":key", Ui.in(mx, my, x, cur, w, rh) && rg.visible(mx, my), dt);
        Render2D.rrect(c, x, cur, w, rh - 2, 4, A(Render2D.mix(Theme.ROW, Theme.HOVER, hv * 0.5f)));
        Render2D.text(c, "Keybind", x + 8, cur + 5, A(Theme.TEXT));
        String kn = binding == m ? "Press a key..." : KeyNames.of(m.key());
        int kw = Render2D.tw(kn) + 12;
        Render2D.rrect(c, x + w - kw - 6, cur + 2, kw, rh - 6, 3, A(binding == m ? Render2D.mix(Theme.PANEL2, Theme.primary(), 0.6f) : Theme.PANEL2));
        Render2D.text(c, kn, x + w - kw, cur + 5, A(Theme.TEXT));
        rg.add(x, cur, w, rh - 2, (px, py, b) -> { binding = m; focus = Focus.NONE; editing = null; }, null);
        cur += rh;

        for (Setting<?> s : m.settings) {
            if (!s.visible()) continue;
            cur += drawSetting(c, s, x, cur, w, mx, my, dt);
        }
        return cur + 2;
    }

    private int drawSetting(DrawContext c, Setting<?> s, int x, int y, int w, int mx, int my, float dt) {
        boolean hot = Ui.in(mx, my, x, y, w, 20) && rg.visible(mx, my);
        float hv = hv(s, hot, dt);
        int rowBg = Render2D.mix(Theme.ROW, Theme.HOVER, hv * 0.5f);

        if (s instanceof BoolSetting b) {
            Render2D.rrect(c, x, y, w, 18, 4, A(rowBg));
            Render2D.text(c, s.name, x + 8, y + 5, A(Theme.TEXT));
            float t = hv(s.name + b.hashCode() + "t", b.on(), dt);
            Ui.toggle(c, x + w - 32, y + 3, 26, 12, t, al, Theme.primary());
            rg.add(x, y, w, 18, (px, py, bt) -> b.toggle(), null);
            return 20;
        }
        if (s instanceof NumSetting n) {
            Render2D.rrect(c, x, y, w, 26, 4, A(rowBg));
            Render2D.text(c, s.name, x + 8, y + 4, A(Theme.TEXT));
            String v = n.isInteger() ? String.valueOf(n.intVal()) : String.format("%.2f", n.val());
            Render2D.text(c, v, x + w - 8 - Render2D.tw(v), y + 4, A(Theme.SILVER));
            int tx = x + 8, tw = w - 16;
            Render2D.rrect(c, tx, y + 17, tw, 4, 2, A(Theme.OFF));
            int fw = Math.max(3, (int) (tw * n.fraction()));
            Render2D.rrect(c, tx, y + 17, fw, 4, 2, A(Render2D.mix(Theme.primary(), Theme.secondary(), (float) n.fraction())));
            Render2D.rrect(c, tx + fw - 3, y + 15, 7, 8, 3, A(0xFFFFFFFF));
            Regions.Drag d = (px, py) -> n.set(n.min + Math.max(0, Math.min(1, (px - tx) / tw)) * (n.max - n.min));
            rg.add(x, y, w, 26, (px, py, bt) -> d.on(px, py), d);
            return 28;
        }
        if (s instanceof ModeSetting ms) {
            Render2D.rrect(c, x, y, w, 18, 4, A(rowBg));
            Render2D.text(c, s.name, x + 8, y + 5, A(Theme.TEXT));
            String v = ms.get() + (dropdown == s ? " ^" : " v");
            int vw = Render2D.tw(v) + 12;
            Render2D.rrect(c, x + w - vw - 6, y + 2, vw, 14, 3, A(Theme.PANEL2));
            Render2D.text(c, v, x + w - vw, y + 5, A(Theme.TEXT));
            rg.add(x, y, w, 18, (px, py, bt) -> { dropdown = dropdown == s ? null : s; picker = null; }, null);
            int used = 20;
            if (dropdown == s) {
                for (String o : ms.options) {
                    boolean sel = o.equals(ms.get());
                    boolean oh = Ui.in(mx, my, x + 12, y + used, w - 24, 16) && rg.visible(mx, my);
                    Render2D.rrect(c, x + 12, y + used, w - 24, 15, 3, A(sel ? Render2D.mix(Theme.PANEL2, Theme.primary(), 0.45f) : oh ? Theme.HOVER : Theme.PANEL2));
                    Render2D.text(c, o, x + 20, y + used + 4, A(sel ? 0xFFFFFFFF : Theme.SILVER));
                    rg.add(x + 12, y + used, w - 24, 15, (px, py, bt) -> { ms.set(o); dropdown = null; }, null);
                    used += 17;
                }
                used += 2;
            }
            return used;
        }
        if (s instanceof ColorSetting cs) {
            Render2D.rrect(c, x, y, w, 18, 4, A(rowBg));
            Render2D.text(c, s.name, x + 8, y + 5, A(Theme.TEXT));
            String hex = String.format("#%06X", cs.rgb() & 0xFFFFFF);
            Render2D.text(c, hex, x + w - 34 - Render2D.tw(hex), y + 5, A(Theme.DIM));
            Render2D.rrect(c, x + w - 28, y + 3, 22, 12, 3, A(cs.rgb()));
            Render2D.outline(c, x + w - 28, y + 3, 22, 12, A(Theme.SILVER));
            rg.add(x, y, w, 18, (px, py, bt) -> {
                if (picker == s) picker = null; else { picker = s; hsv = Colors.toHsv(cs.rgb()); }
                dropdown = null;
            }, null);
            int used = 20;
            if (picker == s) {
                final int sx = x + 10, sy = y + 22, sw = 100, sh = 54, hx = sx + sw + 10;
                for (int i = 0; i < sw; i += 2)
                    c.fillGradient(sx + i, sy, sx + i + 2, sy + sh, A(Colors.hsv(hsv[0], i / (float) sw, 1f)), A(0xFF000000));
                for (int i = 0; i < sh; i += 2) c.fill(hx, sy + i, hx + 10, sy + i + 2, A(Colors.hsv(i / (float) sh, 1f, 1f)));
                int mkx = sx + (int) (hsv[1] * (sw - 1)), mky = sy + (int) ((1 - hsv[2]) * (sh - 1));
                Render2D.outline(c, mkx - 2, mky - 2, 5, 5, A(0xFFFFFFFF));
                int mhy = sy + (int) (hsv[0] * (sh - 1));
                Render2D.outline(c, hx - 1, mhy - 1, 12, 3, A(0xFFFFFFFF));
                Regions.Drag sv = (px, py) -> {
                    hsv[1] = Math.max(0, Math.min(1, (float) (px - sx) / sw));
                    hsv[2] = 1f - Math.max(0, Math.min(1, (float) (py - sy) / sh));
                    cs.set(Colors.hsv(hsv[0], hsv[1], hsv[2]));
                };
                Regions.Drag hue = (px, py) -> {
                    hsv[0] = Math.max(0, Math.min(0.999f, (float) (py - sy) / sh));
                    cs.set(Colors.hsv(hsv[0], hsv[1], hsv[2]));
                };
                rg.add(sx, sy, sw, sh, (px, py, bt) -> sv.on(px, py), sv);
                rg.add(hx, sy, 10, sh, (px, py, bt) -> hue.on(px, py), hue);
                used = 22 + sh + 6;
            }
            return used;
        }
        if (s instanceof StrSetting ss) {
            boolean ed = editing == s;
            Render2D.rrect(c, x, y, w, 18, 4, A(rowBg));
            Render2D.text(c, s.name, x + 8, y + 5, A(Theme.TEXT));
            int fx = x + 8 + Render2D.tw(s.name) + 10, fw = x + w - 6 - fx;
            Render2D.rrect(c, fx, y + 2, fw, 14, 3, A(ed ? Theme.PANEL2 : Theme.BG));
            if (ed) Render2D.outline(c, fx, y + 2, fw, 14, A(Render2D.mix(Theme.PANEL2, Theme.primary(), 0.7f)));
            String v = ed ? text + ((System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "") : (ss.get().isEmpty() ? "(empty)" : ss.get());
            while (Render2D.tw(v) > fw - 8 && v.length() > 1) v = v.substring(1);
            Render2D.text(c, v, fx + 4, y + 5, A(ed || !ss.get().isEmpty() ? Theme.TEXT : Theme.DIM));
            rg.add(x, y, w, 18, (px, py, bt) -> { editing = s; focus = Focus.STRING; text = ss.get(); dropdown = null; picker = null; }, null);
            return 20;
        }
        return 0;
    }

    // =============================================================================================
    private void drawProfilesPage(DrawContext c, int x, int y, int w, int h, int mx, int my, float dt) {
        int fx = x + SB + 14, fw = w - SB - 28, cur = y + 14;
        Render2D.text(c, "Profiles", fx, cur, A(Theme.SILVER));
        Render2D.text(c, "Each profile stores every module, setting, keybind and HUD position.", fx, cur + 12, A(Theme.DIM));
        cur += 32;

        for (String name : ConfigManager.list()) {
            if (cur + 26 > y + h - 120) break;
            boolean act = name.equals(ConfigManager.active());
            float hv = hv("p:" + name, Ui.in(mx, my, fx, cur, fw, 24), dt);
            Render2D.rrect(c, fx, cur, fw, 24, 5, A(Render2D.mix(Theme.PANEL2, Theme.HOVER, hv * 0.5f)));
            if (act) Render2D.rrect(c, fx, cur + 5, 2, 14, 1, A(Theme.primary()));
            Render2D.text(c, name, fx + 12, cur + 8, A(act ? 0xFFFFFFFF : Theme.TEXT));
            int tagX = fx + 12 + Render2D.tw(name) + 8;
            if (act) { Render2D.text(c, "ACTIVE", tagX, cur + 8, A(Theme.primary())); tagX += Render2D.tw("ACTIVE") + 8; }
            if (ConfigManager.isPrivateTest(name)) Render2D.text(c, "PRIVATE TEST", tagX, cur + 8, A(Theme.WARN));
            if (!act) Ui.button(c, rg, fx + fw - 100, cur + 3, 44, 18, "Load", mx, my, al, false, (px, py, b) -> { ConfigManager.switchTo(name); notice(ConfigManager.message); });
            if (!name.equals(ConfigManager.DEFAULT_PROFILE) && !name.equals(ConfigManager.PRIVATE_TEST_PROFILE))
                Ui.button(c, rg, fx + fw - 52, cur + 3, 46, 18, "Delete", mx, my, al, false, (px, py, b) -> { ConfigManager.delete(name); notice(ConfigManager.message); });
            cur += 28;
        }

        int by = y + h - 112;
        Render2D.text(c, "New profile (copies current settings)", fx, by, A(Theme.DIM));
        boolean pf = focus == Focus.PROFILE;
        Render2D.rrect(c, fx, by + 12, fw - 70, 20, 5, A(pf ? Theme.PANEL2 : Theme.ROW));
        if (pf) Render2D.outline(c, fx, by + 12, fw - 70, 20, A(Render2D.mix(Theme.PANEL2, Theme.primary(), 0.7f)));
        Render2D.text(c, newProfile.isEmpty() && !pf ? "name (letters, digits, _ -)" : newProfile + (pf && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : ""), fx + 8, by + 18, A(newProfile.isEmpty() ? Theme.DIM : Theme.TEXT));
        rg.add(fx, by + 12, fw - 70, 20, (px, py, b) -> focus = Focus.PROFILE, null);
        Ui.button(c, rg, fx + fw - 64, by + 12, 64, 20, "Create", mx, my, al, true, (px, py, b) -> createProfile());

        int bw = (fw - 12) / 3;
        Ui.button(c, rg, fx, by + 40, bw, 20, "Export", mx, my, al, false, (px, py, b) -> { ConfigManager.export(); notice(ConfigManager.message); });
        Ui.button(c, rg, fx + bw + 6, by + 40, bw, 20, "Import", mx, my, al, false, (px, py, b) -> { ConfigManager.importFile(); notice(ConfigManager.message); });
        Ui.button(c, rg, fx + 2 * (bw + 6), by + 40, bw, 20, "Reset to defaults", mx, my, al, false, (px, py, b) -> { ConfigManager.reset(); notice(ConfigManager.message); });
        Render2D.text(c, "Export writes config/noctis/export.json. Import reads config/noctis/import.json.", fx, by + 66, A(Theme.DIM));
        if (!ConfigManager.message.isEmpty()) Render2D.text(c, Render2D.trim(ConfigManager.message, fw), fx, by + 80, A(Theme.SILVER));
        if (!ConfigManager.warnings.isEmpty()) Render2D.text(c, Render2D.trim("Repaired: " + ConfigManager.warnings.get(0), fw), fx, by + 92, A(Theme.WARN));
    }

    private void createProfile() {
        ConfigManager.create(newProfile);
        notice(ConfigManager.message);
        newProfile = "";
        focus = Focus.NONE;
    }

    // =============================================================================================
    //  Input (Minecraft 1.21.9+ input event records)
    // =============================================================================================
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        commitText();
        if (binding != null) { binding = null; }
        rg.press(click.x(), click.y(), click.button());
        return true;
    }

    @Override public boolean mouseReleased(Click click) { rg.release(); return true; }

    @Override public boolean mouseDragged(Click click, double dx, double dy) { rg.drag(click.x(), click.y()); return true; }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (page == Page.MODULES && mx > wx + SB) target = Math.max(0, Math.min(target - (float) vertical * 22f, Math.max(0, contentH - viewH)));
        return true;
    }

    private String buf() { return switch (focus) { case SEARCH -> search; case STRING -> text; case PROFILE -> newProfile; default -> ""; }; }
    private void put(String s) { switch (focus) { case SEARCH -> { search = s; target = scroll = 0; } case STRING -> text = s; case PROFILE -> newProfile = s; default -> { } } }

    private void commitText() {
        if (focus == Focus.STRING && editing instanceof StrSetting ss) ss.set(text);
        if (focus == Focus.STRING) editing = null;
        if (focus != Focus.NONE) focus = Focus.NONE;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (binding != null) {
            binding.setKey(key == 256 || key == 259 ? -1 : key);
            binding = null;
            return true;
        }
        if (focus != Focus.NONE) {
            if (key == 256) { editing = null; focus = Focus.NONE; return true; }
            if (key == 257 || key == 335) {
                if (focus == Focus.PROFILE) createProfile(); else commitText();
                return true;
            }
            if (key == 259) { String s = buf(); if (!s.isEmpty()) put(s.substring(0, s.length() - 1)); return true; }
            return true;
        }
        if (key == 256) { closing = true; return true; }
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (focus == Focus.NONE) return false;
        int cp = input.codepoint();
        if (cp < 32 || cp == 127) return false;
        String s = buf();
        int max = focus == Focus.SEARCH ? 40 : focus == Focus.PROFILE ? 32 : (editing instanceof StrSetting ss ? ss.maxLen : 64);
        String ch = new String(Character.toChars(cp));
        if (focus == Focus.PROFILE && !ch.matches("[A-Za-z0-9_-]")) return true;
        if (s.length() < max) put(s + ch);
        return true;
    }

    @Override public void removed() { rg.release(); if (editing instanceof StrSetting ss && focus == Focus.STRING) ss.set(text); ConfigManager.markDirty(); }
}
